<?php
use Phppot\DataSource;
?>
<html>
<head>
<title>Add-Delete-comment</title>
<link rel="stylesheet" type="text/css" href="assets/css/comment.css">
<script src="jquery-3.2.1.min.js"></script>
<script src="assets/js/comment.js"></script>
<style>
.error {
    font-size: 0.9em;
    color: #FF0000;
}
</style>
</head>
<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    session_write_close();
} else {
    // since the username is not set in session, the user is not-logged-in
    // he is trying to access this page unauthorized
    // so let's clear all session variables and redirect him to index
    session_unset();
    session_write_close();
    $url = "./index.php";
    header("Location: $url");
}

?>
<body>
<div class="phppot-container">
<div class="page-content">Welcome <b> <u> <?php echo $username; ?> </u> </b> </div>
<div class="page-header">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;	
<span class="login-signup"><a href="logout.php">Logout</a></span>
		</div>
        </div>
    <h1>Post your comment</h1>
    <div class="comment-form-container">
        <form action="" id="frmComment" method="post">
            <div class="input-row">
                <div class="label">
                    Name: <span id="name-info"></span>
                </div>
                <input class="input-field" id="name" type="text"
                    name="user">
            </div>
            <div class="input-row">
                <div class="label">
                    Message: <span id="message-info"></span>
                </div>
                <textarea class="input-field" id="message"
                    name="message" rows="4"></textarea>
            </div>
            <div>
                <input type="hidden" name="add" value="post" />
                <button type="submit" name="submit" id="submitButton"
                    class="btn-submit">Publish</button>
                <img src="LoaderIcon.gif" id="loader" />
            </div>
        </form>
    </div>

<?php
require_once __DIR__ . '/DataSource.php';
$database = new DataSource();
$sql = "SELECT * from tbl_user_comments ORDER BY id DESC";
$result = $database->select($sql);
?>
<h2>All comments</h2>
<?php
$count = $database->getRecordCount($sql);
if ($count > 0) {
    ?>
        <div id="comment-count">
        <span id="count-number"><?php echo $count;?></span> Comment(s)
    </div>
<?php } ?>
<div id="response">
<?php
if (! empty($result)) {
    foreach ($result as $key => $value) {
        ?>
     <div id="comment-<?php echo $result[$key]["id"];?>"
            class="comment-info">
            <div class="outer-comment">
                <div class="comment-info">
                    <span class="commet-row-label">from</span> <span
                        class="posted-by"><?php echo $result[$key]["username"];?></span>
                    <span class='commet-row-label'>at</span>
				<?php echo $result[$key]["create_at_timestamp"];?>
				</div>
                <div class="comment-text"
                    id="msgdiv-<?php echo $result[$key]["id"];?>">
				<?php echo $result[$key]["message"];?></div>
                <div class="delete" name="delete"
                    id="delete-<?php echo $result[$key]["id"];?>"
                    onclick="deletecomment(<?php echo $result[$key]["id"];?>)">Delete</div>
            </div>
        </div>
<?php
    }
}
?>
</div>
</body>
</html>